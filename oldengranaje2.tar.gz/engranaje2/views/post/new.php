<?php
$this->setLayoutVar('pageTitle', $new ? 'Nuevo Contenido' : 'Editando Contenido');
?>

<?php echo $form ?>
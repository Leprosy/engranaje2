<?php
$this->setLayoutVar('pageTitle', 'Dashboard');
?>
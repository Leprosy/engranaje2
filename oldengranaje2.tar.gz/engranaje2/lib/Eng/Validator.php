<?php

/**
 * A Validator interface
 * 
 * 
 * @package lightvc
 * @author Miguel Rojas
 * @since 2012-01-12
 * */
class Eng_Validator {

    public function __construct($options = array()) {}

    public function isValid($data) {
        return true;
    }
}

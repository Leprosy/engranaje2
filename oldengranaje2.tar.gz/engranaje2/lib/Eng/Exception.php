<?php
/**
 * Lvc classes throw this type of exception.
 *
 * @package lightvc
 * @author Anthony Bush
 * @since 2007-04-20
 **/
class Eng_Exception extends Exception {
	
}